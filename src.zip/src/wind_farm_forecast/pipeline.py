"""End-to-end wind farm forecasting pipeline orchestration."""

from __future__ import annotations

import argparse
import json
import logging
import os
import time

import numpy as np
from sklearn.preprocessing import RobustScaler

from wind_farm_forecast.analysis.statistics import print_stat_summary, run_statistical_tests
from wind_farm_forecast.config import Config
from wind_farm_forecast.data.loader import load_wfd_csv
from wind_farm_forecast.data.synthetic import generate_synthetic_farm
from wind_farm_forecast.evaluation.metrics import compute_metrics
from wind_farm_forecast.features.engineering import build_feature_matrix
from wind_farm_forecast.features.splitting import get_feature_cols, prepare_Xy, temporal_split
from wind_farm_forecast.models.autoregressive import AutoRegForecaster
from wind_farm_forecast.models.dl.trainer import train_dl_models
from wind_farm_forecast.models.hmm_forecaster import HMMForecaster
from wind_farm_forecast.models.ml.models import build_ml_models, train_ml_models
from wind_farm_forecast.models.stacking import StackingEnsemble
from wind_farm_forecast.persistence.model_io import save_all_models
from wind_farm_forecast.reporting.report import save_metrics_report
from wind_farm_forecast.visualization import (
    plot_data_overview,
    plot_dl_training_curves,
    plot_error_distributions,
    plot_feature_importance,
    plot_model_comparison,
    plot_power_curve_analysis,
    plot_predictions_vs_actual,
    plot_radar_comparison,
    plot_scatter_grid,
)

logger = logging.getLogger("WindFarmForecast")

def parse_args():
    p = argparse.ArgumentParser(description="Wind Farm 15-min Forecasting Pipeline")
    p.add_argument("--data_dir",   default="./data_wfd",
                   help="Directory containing WFD CSV files")
    p.add_argument("--output_dir", default="./results",
                   help="Where to save models, plots, and reports")
    p.add_argument("--synthetic",  action="store_true",
                   help="Use synthetic data instead of real CSV files")
    p.add_argument("--skip_dl",    action="store_true",
                   help="Skip deep learning models (faster debugging)")
    p.add_argument("--skip_ar",    action="store_true",
                   help="Skip AutoReg model")
    p.add_argument("--epochs",     type=int, default=None,
                   help="Override DL training epochs")
    return p.parse_args()


def main():
    args = parse_args()
    cfg  = Config(data_dir=args.data_dir, output_dir=args.output_dir)
    if args.epochs:
        cfg.epochs = args.epochs

    t_total = time.time()
    logger.info("=" * 65)
    logger.info("  WIND FARM 15-MINUTE POWER FORECASTING PIPELINE")
    logger.info("=" * 65)

    # ── 1. LOAD DATA ─────────────────────────────────────────────────────────
    if args.synthetic:
        logger.info("Using SYNTHETIC data (--synthetic flag set)")
        df_raw = generate_synthetic_farm(
            start="2018-09-21", end="2024-12-31", n_turbines=12,
            gap_start=cfg.gap_start, gap_end=cfg.gap_end,
        )
    else:
        df_raw = load_wfd_csv(cfg.data_dir, cfg.csv_glob)

    # ── 2. FEATURE ENGINEERING ───────────────────────────────────────────────
    logger.info("Building feature matrix…")
    df_feat, target = build_feature_matrix(df_raw, cfg)
    feature_cols    = get_feature_cols(df_feat, target)
    logger.info(f"Features: {len(feature_cols)} | Target: '{target}'")

    # ── 3. STATISTICAL ANALYSIS ──────────────────────────────────────────────
    logger.info("Running statistical tests…")
    farm_series = df_feat.set_index("timestamp")[target]
    stat_results = run_statistical_tests(farm_series, cfg.output_dir)
    print_stat_summary(stat_results)

    # Save results to JSON
    with open(os.path.join(cfg.output_dir, "reports", "statistical_tests.json"), "w") as f:
        # Convert non-serialisable objects
        clean = {k: (v if isinstance(v, (int, float, bool, str)) else str(v))
                 for k, v in stat_results.items() if k != "ljung_box"}
        json.dump(clean, f, indent=2)

    # ── 4. DATA SPLIT ────────────────────────────────────────────────────────
    logger.info("Splitting data (gap-aware temporal split)…")
    splits = temporal_split(df_feat, cfg)
    plot_data_overview(df_feat, splits, target, cfg.output_dir)

    Xy = prepare_Xy(splits, target, feature_cols)
    X_train, y_train = Xy["train"]
    X_val,   y_val   = Xy["val"]
    X_test,  y_test  = Xy["test"]

    ts_test = splits["test"]["timestamp"].reset_index(drop=True)
    ws_test = splits["test"]["avg_wind_speed_ms"].values

    # ── 5. ML MODELS ─────────────────────────────────────────────────────────
    logger.info("─── Machine Learning Models ───")
    ml_models   = build_ml_models(cfg)
    ml_val_metrics = train_ml_models(ml_models, X_train, y_train,
                                      X_val, y_val, cfg)

    # Test-set predictions for ML
    ml_test_preds = {}
    ml_test_metrics = {}
    for name, pipe in ml_models.items():
        p = pipe.predict(X_test)
        ml_test_preds[name]   = p
        ml_test_metrics[name] = compute_metrics(y_test, p, name)

    # ── 6. DL MODELS ─────────────────────────────────────────────────────────
    dl_trainers, dl_test_metrics, dl_test_preds = {}, {}, {}
    if not args.skip_dl:
        logger.info("─── Deep Learning Models ───")
        dl_trainers, _ = train_dl_models(cfg, X_train, y_train, X_val, y_val)
        for name, trainer in dl_trainers.items():
            p      = trainer.predict(X_test)
            offset = cfg.seq_len
            y_al   = y_test[offset:]
            p_al   = p[:len(y_al)]
            dl_test_preds[name]   = p_al
            dl_test_metrics[name] = compute_metrics(y_al, p_al, name)
        plot_dl_training_curves(dl_trainers, cfg.output_dir)

    # ── 7. AUTOREG MODEL ─────────────────────────────────────────────────────
    ar_model       = None
    ar_test_preds  = {}
    ar_test_metrics = {}
    if not args.skip_ar:
        logger.info("─── AutoReg Model ───")
        try:
            ar_model = AutoRegForecaster(lags=cfg.ar_lags, seasonal=True, period=96)
            ar_model.fit(y_train)
            ar_preds  = ar_model.predict_rolling(y_train, len(y_test))
            ar_preds  = ar_preds[:len(y_test)]
            ar_test_preds["AutoReg"]   = ar_preds
            ar_test_metrics["AutoReg"] = compute_metrics(y_test[:len(ar_preds)],
                                                          ar_preds, "AutoReg")
        except Exception as e:
            logger.warning(f"AutoReg failed: {e}")

    # ── 8. HMM FORECASTER ────────────────────────────────────────────────────
    logger.info("─── HMM Regime-Aware Forecaster ───")
    hmm_model = HMMForecaster(n_states=cfg.n_hmm_states, feature_cols=feature_cols)
    sc_hmm    = RobustScaler()
    X_tr_sc   = sc_hmm.fit_transform(X_train)
    X_te_sc   = sc_hmm.transform(X_test)
    hmm_model.fit(X_tr_sc, y_train)
    hmm_preds = hmm_model.predict(X_te_sc)
    hmm_test_preds    = {"HMMForecaster": hmm_preds}
    hmm_test_metrics  = {"HMMForecaster": compute_metrics(y_test, hmm_preds, "HMMForecaster")}

    # ── 9. STACKING ENSEMBLE ─────────────────────────────────────────────────
    logger.info("─── Stacking Ensemble ───")
    X_trainval = np.vstack([X_train, X_val])
    y_trainval = np.concatenate([y_train, y_val])
    stack = StackingEnsemble(cfg, feature_cols)
    stack_sc      = RobustScaler()
    X_tv_sc       = stack_sc.fit_transform(X_trainval)
    X_te_sc2      = stack_sc.transform(X_test)
    stack.fit(X_tv_sc, y_trainval)
    stack_preds   = stack.predict(X_te_sc2)
    stack_test_preds   = {"Stacking": stack_preds}
    stack_test_metrics = {"Stacking": compute_metrics(y_test, stack_preds, "Stacking")}

    # ── 10. AGGREGATE ALL RESULTS ────────────────────────────────────────────
    all_test_preds = {
        **ml_test_preds,
        **dl_test_preds,
        **ar_test_preds,
        **hmm_test_preds,
        **stack_test_preds,
    }
    all_test_metrics = {
        **ml_test_metrics,
        **dl_test_metrics,
        **ar_test_metrics,
        **hmm_test_metrics,
        **stack_test_metrics,
    }

    # ── 11. REPORTS & PLOTS ──────────────────────────────────────────────────
    logger.info("Generating reports and visualizations…")
    df_ranking = save_metrics_report(all_test_metrics, cfg.output_dir)

    # Align y_test length for models that have the seq_len offset
    y_ref  = y_test
    plot_model_comparison(all_test_metrics, cfg.output_dir)

    # For scatter and error plots use the shortest common length
    min_len = min(len(y_ref), min(len(v) for v in all_test_preds.values()))
    preds_aligned = {n: v[:min_len] for n, v in all_test_preds.items()}
    y_ref_aligned = y_ref[:min_len]
    ts_aligned    = ts_test[:min_len]
    ws_aligned    = ws_test[:min_len]

    plot_predictions_vs_actual(preds_aligned, y_ref_aligned, ts_aligned, cfg.output_dir)
    plot_scatter_grid(preds_aligned, y_ref_aligned, cfg.output_dir)
    plot_error_distributions(preds_aligned, y_ref_aligned, cfg.output_dir)
    plot_feature_importance(ml_models, feature_cols, cfg.output_dir)
    plot_radar_comparison(all_test_metrics, cfg.output_dir)
    plot_power_curve_analysis(preds_aligned, y_ref_aligned, ws_aligned, cfg.output_dir)

    # ── 12. SAVE MODELS ──────────────────────────────────────────────────────
    logger.info("Saving all models…")
    save_all_models(ml_models, dl_trainers, hmm_model, ar_model, stack, cfg.output_dir)

    elapsed = time.time() - t_total
    logger.info(f"\n✓ Pipeline complete in {elapsed/60:.1f} min")
    logger.info(f"  Results → {cfg.output_dir}/")
    logger.info(f"  Plots   → {cfg.output_dir}/plots/")
    logger.info(f"  Models  → {cfg.output_dir}/models/")


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    main()

"""Run the pipeline with `python -m wind_farm_forecast`."""

from .pipeline import main

if __name__ == "__main__":
    main()

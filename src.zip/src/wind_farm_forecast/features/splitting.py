"""Temporal split and feature/target extraction helpers."""

from __future__ import annotations

import logging
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

from wind_farm_forecast.config import Config

logger = logging.getLogger("WindFarmForecast")

def temporal_split(df: pd.DataFrame, cfg: Config) -> Dict[str, pd.DataFrame]:
    
    ts = df["timestamp"]
    splits = {
        "train": df[ts <= cfg.train_end].copy(),
        "val":   df[(ts > cfg.train_end) & (ts <= cfg.val_end)].copy(),
        "test":  df[ts >= cfg.test_start].copy(),
    }
    for name, part in splits.items():
        logger.info(f"Split '{name}': {len(part):>8,} rows  "
                    f"[{part['timestamp'].min().date()} → "
                    f"{part['timestamp'].max().date()}]")
    return splits


def prepare_Xy(
    splits: Dict[str, pd.DataFrame],
    target: str,
    feature_cols: List[str],
) -> Dict[str, Tuple]:
    
    out = {}
    for name, part in splits.items():
        X = part[feature_cols].values
        y = part[target].values
        out[name] = (X, y)
    return out


def get_feature_cols(df: pd.DataFrame, target: str) -> List[str]:
    
    LEAKY_COLS = {
        "farm_power_kw",   # = production_kwh / 0.25h — same quantity, different units
        "n_turbines_producing",  # count of turbines with power_kw > 50 at this step
        "availability_ratio",    # derived from n_turbines_producing
        "avg_reactive_kvar",     # measured simultaneously with real power output
    }
    drop = {"timestamp", "Date", target} | LEAKY_COLS
    drop.update(c for c in df.columns if df[c].dtype == object)
    return [c for c in df.columns if c not in drop and
            np.issubdtype(df[c].dtype, np.number)]

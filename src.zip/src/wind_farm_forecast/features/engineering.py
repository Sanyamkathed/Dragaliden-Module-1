"""Feature engineering pipeline for turbine-level wind farm data."""

from __future__ import annotations

import logging
from typing import List, Tuple

import numpy as np
import pandas as pd

from wind_farm_forecast.constants import FARM_MAX_KW, MAX_DELTA_KWH, MAX_POWER_KW

logger = logging.getLogger("WindFarmForecast")

def compute_production(df_wfd: pd.DataFrame) -> pd.DataFrame:
    
    df = df_wfd.copy().sort_values(["PlantNo", "timestamp"])
    df["production_kwh"] = df.groupby("PlantNo")["energy_ctr_kwh"].diff()
    df.loc[df["production_kwh"] < 0, "production_kwh"] = 0
    df.loc[df["production_kwh"] > MAX_DELTA_KWH * 4, "production_kwh"] = np.nan
    return df


def compute_farm_totals(df: pd.DataFrame) -> pd.DataFrame:
    
    agg = df.groupby("timestamp").agg(
        farm_power_kw       = ("power_kw",       "sum"),
        farm_production_kwh = ("production_kwh",  "sum"),
        avg_wind_speed_ms   = ("wind_speed_ms",   "mean"),
        std_wind_speed_ms   = ("wind_speed_ms",   "std"),
        min_wind_speed_ms   = ("wind_speed_ms",   "min"),
        max_wind_speed_ms   = ("wind_speed_ms",   "max"),
        avg_nacelle_deg     = ("nacelle_pos_deg", "mean"),
        std_nacelle_deg     = ("nacelle_pos_deg", "std"),
        avg_reactive_kvar   = ("reactive_kvar",   "mean"),
        n_turbines_total    = ("PlantNo",         "count"),
        n_turbines_producing = ("power_kw",       lambda x: (x > 50).sum()),
        n_turbines_error    = ("Error",           lambda x: (x > 0).sum()),
        avg_error_code      = ("Error",           "mean"),
    ).reset_index()

    agg["availability_ratio"] = agg["n_turbines_producing"] / agg["n_turbines_total"].clip(1)
    agg["wind_dir_spread"]    = agg["std_nacelle_deg"].fillna(0)
    agg["farm_power_kw"]      = agg["farm_power_kw"].clip(lower=0, upper=FARM_MAX_KW)
    agg = agg.sort_values("timestamp").reset_index(drop=True)
    return agg


def _cyclical_encode(val: pd.Series, period: float) -> Tuple:
    
    angle = 2.0 * np.pi * val / period
    return np.sin(angle), np.cos(angle)


def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
    
    ts = df["timestamp"]
    df["hour_sin"],   df["hour_cos"]   = _cyclical_encode(ts.dt.hour + ts.dt.minute/60, 24)
    df["dow_sin"],    df["dow_cos"]    = _cyclical_encode(ts.dt.dayofweek, 7)
    df["month_sin"],  df["month_cos"]  = _cyclical_encode(ts.dt.month, 12)
    df["doy_sin"],    df["doy_cos"]    = _cyclical_encode(ts.dt.dayofyear, 365.25)
    df["quarter"]  = ts.dt.quarter.astype(np.int8)
    df["is_night"] = ((ts.dt.hour < 6) | (ts.dt.hour >= 22)).astype(np.int8)
    df["is_summer"] = ts.dt.month.isin([6,7,8]).astype(np.int8)
    df["is_winter"] = ts.dt.month.isin([12,1,2]).astype(np.int8)
    return df


def add_lag_features(df: pd.DataFrame, target: str, lags: List[int]) -> pd.DataFrame:
    
    for lag in lags:
        df[f"{target}_lag_{lag}"] = df[target].shift(lag)
        if "avg_wind_speed_ms" in df.columns:
            df[f"wind_lag_{lag}"] = df["avg_wind_speed_ms"].shift(lag)
    return df


def add_rolling_features(df: pd.DataFrame, target: str, windows: List[int]) -> pd.DataFrame:
    
    for w in windows:
        r = df[target].shift(1).rolling(w)
        df[f"{target}_roll_mean_{w}"] = r.mean()
        df[f"{target}_roll_std_{w}"]  = r.std()
        df[f"{target}_roll_min_{w}"]  = r.min()
        df[f"{target}_roll_max_{w}"]  = r.max()
        if "avg_wind_speed_ms" in df.columns:
            rw = df["avg_wind_speed_ms"].shift(1).rolling(w)
            df[f"wind_roll_mean_{w}"] = rw.mean()
    return df


def add_derivative_features(df: pd.DataFrame, target: str) -> pd.DataFrame:
    
    df[f"{target}_diff1"]  = df[target].shift(1).diff(1)
    df[f"{target}_diff2"]  = df[target].shift(1).diff(2)
    df["wind_diff1"]        = df["avg_wind_speed_ms"].shift(1).diff(1) if "avg_wind_speed_ms" in df.columns else 0
    return df


def add_wind_power_physics(df: pd.DataFrame) -> pd.DataFrame:
    
    if "avg_wind_speed_ms" in df.columns:
        df["wind_cube"]       = df["avg_wind_speed_ms"] ** 3
        df["wind_sq"]         = df["avg_wind_speed_ms"] ** 2
        # Wind-direction consistency (nacelle spread → wake losses proxy)
        if "wind_dir_spread" in df.columns:
            df["wake_proxy"]  = df["wind_dir_spread"] / (df["avg_wind_speed_ms"].clip(0.1))
    return df


def build_feature_matrix(
    df_turbine: pd.DataFrame,
    cfg: "Config",
) -> Tuple[pd.DataFrame, str]:
    
    
    df_turbine = compute_production(df_turbine)

    
    df = compute_farm_totals(df_turbine)
    target = "farm_production_kwh"

    
    df = add_time_features(df)

    
    df = add_lag_features(df, target, cfg.lag_steps)
    
    df = add_rolling_features(df, target, cfg.rolling_windows)

    
    df = add_derivative_features(df, target)

    
    df = add_wind_power_physics(df)

    
    initial = len(df)
    df = df.dropna().reset_index(drop=True)
    logger.info(f"Feature matrix: {initial} → {len(df)} rows after lag/rolling NaN drop")

    return df, target

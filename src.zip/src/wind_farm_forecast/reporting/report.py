"""Metrics reporting helpers."""

from __future__ import annotations

import logging
import os
from typing import Dict

import pandas as pd

logger = logging.getLogger("WindFarmForecast")

def save_metrics_report(all_metrics: Dict, out_dir: str):
    
    df_r = pd.DataFrame(list(all_metrics.values()))
    df_r = df_r.sort_values("RMSE").reset_index(drop=True)
    df_r.index = df_r.index + 1 
    df_r.index.name = "Rank"

    csv_p = os.path.join(out_dir, "reports", "model_metrics.csv")
    df_r.to_csv(csv_p)
    logger.info(f"Metrics CSV saved → {csv_p}")

    sep = "═" * 80
    print(f"\n{sep}")
    print("  MODEL PERFORMANCE SUMMARY  (sorted by RMSE ascending)")
    print(sep)
    header = f"{'Rank':>4}  {'Model':<22}  {'MAE':>7}  {'RMSE':>7}  "
    header += f"{'nRMSE%':>7}  {'SMAPE%':>7}  {'R²':>7}  {'MBE':>8}"
    print(header)
    print("─" * 80)
    for _, row in df_r.iterrows():
        print(f"{row.name:>4}  {row['model']:<22}  "
              f"{row['MAE']:>7,.0f}  {row['RMSE']:>7,.0f}  "
              f"{row['nRMSE%']:>7.2f}  {row['SMAPE%']:>7.2f}  "
              f"{row['R2']:>7.4f}  {row['MBE']:>8.0f}")
    print(sep)

    # Best model callout
    best = df_r.iloc[0]
    print(f"\n   Best model: {best['model']}  "
          f"(RMSE={best['RMSE']:,.0f} kW  |  R²={best['R2']:.4f})\n")
    return df_r

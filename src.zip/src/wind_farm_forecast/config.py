"""Configuration, logging, seeds, and runtime device selection."""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

import numpy as np
import torch

warnings.filterwarnings("ignore")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("WindFarmForecast")

SEED = 42
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def set_seeds(seed: int = SEED) -> None:
    """Set NumPy and PyTorch random seeds."""
    np.random.seed(seed)
    torch.manual_seed(seed)


set_seeds(SEED)
logger.info(f"PyTorch device : {DEVICE}")


@dataclass
class Config:
    # Paths
    data_dir: str = "./data_wfd"
    output_dir: str = "./results"
    csv_glob: str = "**/*.csv"

    # Temporal split (gap-aware)
    train_end: str = "2023-08-31"
    val_end: str = "2023-11-30"
    gap_start: str = "2023-12-01"
    gap_end: str = "2024-06-30"
    test_start: str = "2024-07-01"

    # Feature engineering
    n_turbines: int = 12
    lag_steps: List[int] = field(default_factory=lambda: [1, 2, 3, 4, 8, 12, 24, 48, 96])
    rolling_windows: List[int] = field(default_factory=lambda: [4, 12, 24, 48, 96])

    # DL hyper-params
    seq_len: int = 96
    batch_size: int = 256
    epochs: int = 5
    lr: float = 1e-3
    patience: int = 15

    # LSTM / GRU
    hidden_dim: int = 128
    n_lstm_layers: int = 2
    dropout: float = 0.25

    # Transformer
    d_model: int = 64
    nhead: int = 4
    n_tf_layers: int = 3
    ff_dim: int = 256
    tf_dropout: float = 0.15

    # AR / HMM / Evaluation
    ar_lags: int = 96
    n_hmm_states: int = 4
    cv_folds: int = 5

    def __post_init__(self) -> None:
        for sub in ["", "models", "plots", "reports"]:
            Path(self.output_dir, sub).mkdir(parents=True, exist_ok=True)

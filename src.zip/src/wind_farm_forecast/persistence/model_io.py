"""Model serialization helpers."""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional

import joblib

logger = logging.getLogger("WindFarmForecast")

def save_all_models(
    ml_models:   Dict,
    dl_trainers: Dict,
    hmm_model:   Optional["HMMForecaster"],
    ar_model:    Optional["AutoRegForecaster"],
    stack:       Optional["StackingEnsemble"],
    out_dir:     str,
):
    
    model_dir = os.path.join(out_dir, "models")
    saved = []

    for name, pipe in ml_models.items():
        p = os.path.join(model_dir, f"{name}.pkl")
        joblib.dump(pipe, p)
        saved.append(p)

    for name, trainer in dl_trainers.items():
        p = os.path.join(model_dir, f"{name}.pkl")
        trainer.save(p)
        saved.append(p)

    if hmm_model is not None:
        p = os.path.join(model_dir, "HMMForecaster.pkl")
        hmm_model.save(p)
        saved.append(p)

    if ar_model is not None:
        p = os.path.join(model_dir, "AutoReg.pkl")
        ar_model.save(p)
        saved.append(p)

    if stack is not None:
        p = os.path.join(model_dir, "Stacking.pkl")
        stack.save(p)
        saved.append(p)

    logger.info(f"All models saved to '{model_dir}' ({len(saved)} files)")
    return saved


def load_model(path: str) -> Any:
    """Load any saved model by path."""
    return joblib.load(path)

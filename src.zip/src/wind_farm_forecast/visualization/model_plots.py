"""Model comparison visualizations."""

from __future__ import annotations

import logging
import os
from typing import Dict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, r2_score

from wind_farm_forecast.visualization.palette import PALETTE

logger = logging.getLogger("WindFarmForecast")

def plot_model_comparison(all_metrics: Dict, out_dir: str):
    """Bar-chart comparison of all models across MAE, RMSE, R², SMAPE."""
    df_m = pd.DataFrame(list(all_metrics.values()))
    df_m = df_m.sort_values("RMSE")
    models = df_m["model"].tolist()
    colors = [PALETTE.get(m, "#607d8b") for m in models]

    fig, axes = plt.subplots(2, 2, figsize=(16, 10))
    fig.suptitle("Model Comparison – Validation Set", fontsize=15, fontweight="bold")

    for ax, (metric, label, best) in zip(axes.ravel(), [
        ("MAE",    "MAE (kW) ↓",    "min"),
        ("RMSE",   "RMSE (kW) ↓",   "min"),
        ("R2",     "R² Score ↑",    "max"),
        ("SMAPE%", "sMAPE (%) ↓",   "min"),
    ]):
        vals = df_m[metric].values
        bars = ax.barh(models, vals, color=colors, edgecolor="white", height=0.65)
        best_idx = np.argmin(vals) if best == "min" else np.argmax(vals)
        bars[best_idx].set_edgecolor("gold")
        bars[best_idx].set_linewidth(3)
        for i, (bar, v) in enumerate(zip(bars, vals)):
            ax.text(v * 1.01 if best == "min" else v + 0.002,
                    bar.get_y() + bar.get_height() / 2,
                    f"{v:.3f}" if metric in ("R2","SMAPE%") else f"{v:,.0f}",
                    va="center", fontsize=7.5)
        ax.set_xlabel(label); ax.set_title(label)
        ax.invert_yaxis(); ax.grid(axis="x", alpha=0.3)
    plt.tight_layout()
    p = os.path.join(out_dir, "plots", "03_model_comparison.png")
    plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    logger.info(f"Saved → {p}")


def plot_predictions_vs_actual(predictions: Dict, y_true: np.ndarray,
                               timestamps: pd.Series, out_dir: str, n_days: int = 7):
    
    n_plot = min(n_days * 96, len(y_true))
    ts_sel = timestamps.values[:n_plot]
    y_sel  = y_true[:n_plot]

    # Rank models by R2 on full test
    ranked = sorted(predictions.items(),
                    key=lambda kv: r2_score(
                        y_true[:min(len(y_true), len(kv[1]))],
                        kv[1][:min(len(y_true), len(kv[1]))]
                    ), reverse=True)[:5]

    fig, axes = plt.subplots(len(ranked), 1, figsize=(18, 3.5 * len(ranked)),
                             sharex=True)
    if len(ranked) == 1:
        axes = [axes]
    fig.suptitle(f"Top-5 Models – Predictions vs Actual ({n_days}-day window)",
                 fontsize=13, fontweight="bold")

    for ax, (name, pred) in zip(axes, ranked):
        p_sel = pred[:n_plot]
        ax.plot(ts_sel, y_sel, color="#37474f", lw=1.2, label="Actual", alpha=0.9)
        ax.plot(ts_sel, p_sel, color=PALETTE.get(name, "#e53935"), lw=1.0,
                label=name, ls="--", alpha=0.85)
        ax.fill_between(ts_sel, y_sel, p_sel,
                        alpha=0.15, color=PALETTE.get(name, "#e53935"))
        mae_here = mean_absolute_error(y_sel[:len(p_sel)], p_sel)
        ax.set_ylabel("Power (kW)"); ax.legend(loc="upper left", fontsize=8)
        ax.set_title(f"{name}  –  MAE={mae_here:,.0f} kW (this window)", fontsize=10)
        ax.grid(alpha=0.25)
    axes[-1].set_xlabel("Time")
    plt.tight_layout()
    p = os.path.join(out_dir, "plots", "04_predictions_vs_actual.png")
    plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    logger.info(f"Saved → {p}")


def plot_scatter_grid(predictions: Dict, y_true: np.ndarray, out_dir: str):
    
    names  = list(predictions.keys())
    n      = len(names)
    ncols  = 4
    nrows  = (n + ncols - 1) // ncols
    fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 4.5 * nrows))
    axes = axes.ravel()
    fig.suptitle("Predicted vs Actual – All Models (Test Set)", fontsize=13, fontweight="bold")

    for ax, name in zip(axes, names):
        pred = predictions[name]
        ln   = min(len(y_true), len(pred))
        yt, yp = y_true[:ln], pred[:ln]
        ax.scatter(yt, yp, s=1, alpha=0.3, c=PALETTE.get(name, "#607d8b"), rasterized=True)
        lim = [min(yt.min(), yp.min()), max(yt.max(), yp.max())]
        ax.plot(lim, lim, "k--", lw=0.8, alpha=0.5)
        r2 = r2_score(yt, yp)
        ax.set_title(f"{name}\nR²={r2:.4f}", fontsize=9)
        ax.set_xlabel("Actual (kW)", fontsize=8); ax.set_ylabel("Predicted (kW)", fontsize=8)
    for ax in axes[n:]:
        ax.set_visible(False)
    plt.tight_layout()
    p = os.path.join(out_dir, "plots", "05_scatter_plots.png")
    plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    logger.info(f"Saved → {p}")


def plot_radar_comparison(all_metrics: Dict, out_dir: str):
    
    metrics_keys = ["R2", "nRMSE%", "SMAPE%", "nMAE%"]
    models  = list(all_metrics.keys())
    N       = len(metrics_keys)
    angles  = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(9, 9),
                            subplot_kw=dict(polar=True))
    ax.set_title("Radar Comparison – Normalised Metrics (Test Set)",
                 fontsize=12, y=1.08)

    for name, m in all_metrics.items():
        vals = []
        for k in metrics_keys:
            v = m.get(k, 0)
            if k == "R2":
                v = max(0, v)         
            else:
                v = min(v / 10.0, 1.0) 
            vals.append(v)
        vals += vals[:1]
        ax.plot(angles, vals, lw=1.5, label=name,
                color=PALETTE.get(name, "#607d8b"))
        ax.fill(angles, vals, alpha=0.07, color=PALETTE.get(name, "#607d8b"))

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(["R²↑", "nRMSE↓", "sMAPE↓", "nMAE↓"], fontsize=11)
    ax.set_yticks([0.2, 0.4, 0.6, 0.8])
    ax.legend(loc="upper right", bbox_to_anchor=(1.35, 1.1), fontsize=8)
    ax.grid(alpha=0.4)
    plt.tight_layout()
    p = os.path.join(out_dir, "plots", "09_radar_comparison.png")
    plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    logger.info(f"Saved → {p}")

"""Shared model colour palette."""

PALETTE = {
    "LinearRegression": "#9e9e9e",
    "Ridge":            "#78909c",
    "RandomForest":     "#2e7d32",
    "XGBoost":          "#1565c0",
    "LightGBM":         "#00838f",
    "SVR":              "#6a1b9a",
    "LSTM":             "#e65100",
    "GRU":              "#f57f17",
    "CNN_LSTM":         "#ad1457",
    "Transformer":      "#880e4f",
    "AutoReg":          "#795548",
    "HMMForecaster":    "#37474f",
    "Stacking":         "#b71c1c",
}

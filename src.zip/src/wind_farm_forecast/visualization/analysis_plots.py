"""Residual, feature-importance, training, and power-curve plots."""

from __future__ import annotations

import logging
import os
from typing import Dict, List

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import r2_score

from wind_farm_forecast.models.ml.models import get_feature_importance
from wind_farm_forecast.visualization.palette import PALETTE

logger = logging.getLogger("WindFarmForecast")

def plot_error_distributions(predictions: Dict, y_true: np.ndarray, out_dir: str):
    
    names  = list(predictions.keys())
    errors = {}
    for name, pred in predictions.items():
        ln = min(len(y_true), len(pred))
        errors[name] = pred[:ln] - y_true[:ln]

    fig, axes = plt.subplots(1, 2, figsize=(18, 7))
    fig.suptitle("Residual Analysis – Test Set", fontsize=13, fontweight="bold")

    # Violin
    ax = axes[0]
    parts = ax.violinplot([errors[n] for n in names],
                          positions=range(len(names)), showmedians=True)
    for i, (pc, name) in enumerate(zip(parts["bodies"], names)):
        pc.set_facecolor(PALETTE.get(name, "#607d8b"))
        pc.set_alpha(0.7)
    ax.axhline(0, color="red", lw=1, ls="--")
    ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=45, ha="right")
    ax.set_ylabel("Residual (kW)"); ax.set_title("Residual Violin Plots")

    # Sorted MAE bar
    ax = axes[1]
    mae_vals = {n: np.abs(errors[n]).mean() for n in names}
    sorted_n = sorted(mae_vals, key=mae_vals.get)
    barcolors = [PALETTE.get(n, "#607d8b") for n in sorted_n]
    bars = ax.barh(sorted_n, [mae_vals[n] for n in sorted_n],
                   color=barcolors, edgecolor="white", height=0.6)
    bars[0].set_edgecolor("gold"); bars[0].set_linewidth(3)
    ax.set_xlabel("MAE (kW)"); ax.set_title("Test MAE – Sorted Ranking")
    ax.invert_yaxis(); ax.grid(axis="x", alpha=0.3)
    for bar, n in zip(bars, sorted_n):
        ax.text(bar.get_width() * 1.01, bar.get_y() + bar.get_height() / 2,
                f"{mae_vals[n]:,.0f}", va="center", fontsize=8)
    plt.tight_layout()
    p = os.path.join(out_dir, "plots", "06_error_distributions.png")
    plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    logger.info(f"Saved → {p}")


def plot_feature_importance(ml_models: Dict, feature_cols: List[str], out_dir: str):
    
    tree_models = {n: p for n, p in ml_models.items()
                   if n in ("RandomForest", "XGBoost", "LightGBM")}
    if not tree_models:
        return

    ncols = len(tree_models)
    fig, axes = plt.subplots(1, ncols, figsize=(8 * ncols, 10))
    if ncols == 1:
        axes = [axes]
    fig.suptitle("Feature Importances – Tree-Based Models (Top 25)", fontsize=13)

    for ax, (name, pipe) in zip(axes, tree_models.items()):
        fi = get_feature_importance(pipe, feature_cols)
        if fi.empty:
            continue
        fi = fi.head(25)
        colors = plt.cm.YlOrRd(np.linspace(0.4, 0.9, len(fi)))[::-1]
        ax.barh(fi["feature"], fi["importance"], color=colors, edgecolor="white")
        ax.set_title(name); ax.invert_yaxis()
        ax.set_xlabel("Importance"); ax.tick_params(labelsize=8)
    plt.tight_layout()
    p = os.path.join(out_dir, "plots", "07_feature_importance.png")
    plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    logger.info(f"Saved → {p}")


def plot_dl_training_curves(dl_trainers: Dict, out_dir: str):
    
    n     = len(dl_trainers)
    ncols = min(n, 2)
    nrows = (n + 1) // 2
    fig, axes = plt.subplots(nrows, ncols, figsize=(10 * ncols, 4.5 * nrows))
    axes = np.array(axes).ravel()
    fig.suptitle("Deep Learning – Training & Validation Loss", fontsize=13)

    for ax, (name, trainer) in zip(axes, dl_trainers.items()):
        hist = trainer.history
        ep   = range(1, len(hist["train_loss"]) + 1)
        ax.plot(ep, hist["train_loss"], color="#1565c0", lw=1.5, label="Train")
        ax.plot(ep, hist["val_loss"],   color="#c62828", lw=1.5, label="Val", ls="--")
        best_ep = int(np.argmin(hist["val_loss"])) + 1
        ax.axvline(best_ep, color="green", lw=1, ls=":", alpha=0.8, label=f"Best epoch={best_ep}")
        ax.set_title(name); ax.set_xlabel("Epoch"); ax.set_ylabel("Huber Loss")
        ax.legend(fontsize=8); ax.grid(alpha=0.3)
    for ax in axes[n:]:
        ax.set_visible(False)
    plt.tight_layout()
    p = os.path.join(out_dir, "plots", "08_dl_training_curves.png")
    plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    logger.info(f"Saved → {p}")


def plot_power_curve_analysis(predictions: Dict, y_true: np.ndarray,
                              wind_speed: np.ndarray, out_dir: str):
    
    best_name = max(
        {n: r2_score(y_true[:min(len(y_true), len(p))], p[:min(len(y_true), len(p))])
         for n, p in predictions.items()}.items(),
        key=lambda x: x[1]
    )[0]
    pred  = predictions[best_name]
    ln    = min(len(y_true), len(pred), len(wind_speed))
    ws    = wind_speed[:ln]; ya = y_true[:ln]; yp = pred[:ln]

    bins  = np.arange(0, 26, 0.5)
    ya_m  = [ya[(ws >= b) & (ws < b+0.5)].mean() for b in bins]
    yp_m  = [yp[(ws >= b) & (ws < b+0.5)].mean() for b in bins]
    cnt   = [((ws >= b) & (ws < b+0.5)).sum() for b in bins]

    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    fig.suptitle(f"Power Curve Analysis – Best Model: {best_name}", fontsize=13)

    ax = axes[0]
    ax.scatter(ws[::5], ya[::5], s=1, alpha=0.2, c="#37474f", label="Actual")
    ax.scatter(ws[::5], yp[::5], s=1, alpha=0.2, c=PALETTE.get(best_name,"#e53935"),
               label=best_name)
    ax.set_xlabel("Wind Speed (m/s)"); ax.set_ylabel("Farm Power (kW)")
    ax.set_title("Raw Scatter"); ax.legend(markerscale=10, fontsize=9)

    ax = axes[1]
    valid = [i for i,c in enumerate(cnt) if c > 5]
    ax.plot([bins[i] for i in valid], [ya_m[i] for i in valid],
            "o-", color="#37474f", lw=2, label="Actual (binned)")
    ax.plot([bins[i] for i in valid], [yp_m[i] for i in valid],
            "s--", color=PALETTE.get(best_name, "#e53935"), lw=2, label=best_name)
    ax.set_xlabel("Wind Speed (m/s)"); ax.set_ylabel("Mean Farm Power (kW)")
    ax.set_title("Binned Power Curve"); ax.legend(fontsize=9); ax.grid(alpha=0.3)
    plt.tight_layout()
    p = os.path.join(out_dir, "plots", "10_power_curve_analysis.png")
    plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    logger.info(f"Saved → {p}")

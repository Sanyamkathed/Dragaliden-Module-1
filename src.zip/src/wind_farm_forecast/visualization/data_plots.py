"""Data overview visualizations."""

from __future__ import annotations

import logging
import os
from typing import Dict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

logger = logging.getLogger("WindFarmForecast")

def plot_data_overview(df: pd.DataFrame, splits: Dict, target: str, out_dir: str):
    
    fig, axes = plt.subplots(3, 1, figsize=(18, 12))
    fig.suptitle("Wind Farm Data Overview", fontsize=15, fontweight="bold")

    # Downsample for plotting
    sample = df.set_index("timestamp").resample("1h").mean().reset_index()

    # Power time series
    ax = axes[0]
    ax.fill_between(sample["timestamp"], sample[target],
                    color="#1565c0", alpha=0.4, label="Farm Power (kW)")
    ax.plot(sample["timestamp"], sample[target], color="#1565c0", lw=0.4)

    # Color-code splits
    colors = {"train": "#2e7d32", "val": "#f57f17", "test": "#c62828"}
    for sname, sdf in splits.items():
        ax.axvspan(sdf["timestamp"].min(), sdf["timestamp"].max(),
                   alpha=0.08, color=colors.get(sname, "grey"),
                   label=sname.capitalize())
    ax.set_title("Farm Total Power – Hourly Average (coloured by split)")
    ax.set_xlabel("Time"); ax.set_ylabel("Power (kW)")
    ax.legend(fontsize=9, loc="upper right", ncol=4)

    # Wind speed distribution
    ax = axes[1]
    ax.hist(df["avg_wind_speed_ms"].dropna(), bins=80,
            color="#2e7d32", alpha=0.75, edgecolor="none")
    ax.axvline(df["avg_wind_speed_ms"].mean(), color="red", lw=1.5, ls="--",
               label=f"Mean {df['avg_wind_speed_ms'].mean():.1f} m/s")
    ax.set_title("Farm Average Wind Speed Distribution")
    ax.set_xlabel("Wind Speed (m/s)"); ax.set_ylabel("Count")
    ax.legend()

    # Monthly heatmap
    ax = axes[2]
    df_m = df.copy()
    df_m["year"]  = df_m["timestamp"].dt.year
    df_m["month"] = df_m["timestamp"].dt.month
    pivot = df_m.pivot_table(values=target, index="year", columns="month", aggfunc="mean")
    im = ax.imshow(pivot.values, aspect="auto", cmap="YlOrRd", interpolation="nearest")
    ax.set_xticks(range(12))
    ax.set_xticklabels(["Jan","Feb","Mar","Apr","May","Jun",
                         "Jul","Aug","Sep","Oct","Nov","Dec"])
    ax.set_yticks(range(len(pivot.index)))
    ax.set_yticklabels(pivot.index.astype(int))
    ax.set_title("Average Farm Power by Month × Year (kW)")
    plt.colorbar(im, ax=ax, label="Avg Power (kW)")

    plt.tight_layout()
    p = os.path.join(out_dir, "plots", "02_data_overview.png")
    plt.savefig(p, dpi=150, bbox_inches="tight"); plt.close(fig)
    logger.info(f"Saved → {p}")

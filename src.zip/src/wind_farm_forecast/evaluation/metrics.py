"""Forecasting metrics."""

from __future__ import annotations

from typing import Dict

import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from wind_farm_forecast.constants import FARM_MAX_KWH

def smape(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    denom = (np.abs(y_true) + np.abs(y_pred)) / 2.0
    return float(np.mean(np.abs(y_pred - y_true) / np.clip(denom, 1e-3, None)) * 100)

def mbe(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(y_pred - y_true))

def nmae(y_true: np.ndarray, y_pred: np.ndarray, capacity: float = FARM_MAX_KWH) -> float:
    return mean_absolute_error(y_true, y_pred) / capacity * 100

def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray,
                    name: str = "") -> Dict:
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    mask   = np.isfinite(y_true) & np.isfinite(y_pred)
    y_true, y_pred = y_true[mask], y_pred[mask]

    mae   = mean_absolute_error(y_true, y_pred)
    rmse  = np.sqrt(mean_squared_error(y_true, y_pred))
    r2    = r2_score(y_true, y_pred)
    smape_val = smape(y_true, y_pred)
    mbe_val   = mbe(y_true, y_pred)
    nmae_val  = nmae(y_true, y_pred)

    # Normalised RMSE
    nrmse = rmse / FARM_MAX_KWH * 100

    return {
        "model":  name,
        "MAE":    round(mae, 2),
        "RMSE":   round(rmse, 2),
        "nRMSE%": round(nrmse, 3),
        "SMAPE%": round(smape_val, 3),
        "nMAE%":  round(nmae_val, 3),
        "MBE":    round(mbe_val, 2),
        "R2":     round(r2, 4),
    }

"""Pre-modelling statistical analysis for the target time series."""

from __future__ import annotations

import logging
import os
from typing import Dict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import jarque_bera
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.tsa.seasonal import STL
from statsmodels.tsa.stattools import adfuller

from wind_farm_forecast.config import SEED

logger = logging.getLogger("WindFarmForecast")

def run_statistical_tests(series: pd.Series, out_dir: str) -> Dict:
    
    results = {}
    series = series.dropna()
    n = len(series)

    # ── ADF Test
    adf_stat, p_val, _, _, crit, _ = adfuller(series, autolag="AIC", maxlag=20)
    results["adf"] = {
        "statistic": round(adf_stat, 4),
        "p_value":   round(p_val, 6),
        "stationary": bool(p_val < 0.05),
        "critical_1pct": crit["1%"],
    }
    logger.info(f"ADF test  → stat={adf_stat:.3f}  p={p_val:.4f}  "
                f"{'STATIONARY' if p_val < 0.05 else 'NON-STATIONARY'}")

    # ── Ljung-Box
    lb = acorr_ljungbox(series, lags=[1, 4, 12, 48, 96], return_df=True)
    results["ljung_box"] = lb.to_dict()
    logger.info(f"Ljung-Box (lag=96) p={lb['lb_pvalue'].iloc[-1]:.4e}")

    # ── Normality
    jb_stat, jb_p = jarque_bera(series)
    results["jarque_bera"] = {"statistic": round(jb_stat, 2), "p_value": round(jb_p, 6)}
    skew  = float(series.skew())
    kurt  = float(series.kurtosis())
    results["skewness"] = round(skew, 4)
    results["excess_kurtosis"] = round(kurt, 4)
    logger.info(f"Jarque-Bera p={jb_p:.4e} | skew={skew:.2f} | kurt={kurt:.2f}")

    # ── Coefficient of Variation
    results["cv_pct"] = round(series.std() / series.mean() * 100, 2)

    # ── Plots
    fig, axes = plt.subplots(3, 2, figsize=(16, 14))
    fig.suptitle("Statistical Analysis – Farm Total Power (kW)", fontsize=14, fontweight="bold")

    # Distribution
    ax = axes[0, 0]
    sample = series.sample(min(50_000, n), random_state=SEED)
    ax.hist(sample, bins=100, color="#2e7d32", alpha=0.75, edgecolor="none")
    ax.set_title("Power Distribution")
    ax.set_xlabel("Farm Power (kW)")
    ax2 = ax.twinx()
    sns.kdeplot(sample, ax=ax2, color="navy", lw=1.5)
    ax.set_ylabel("Count"); ax2.set_ylabel("Density")

    # Q-Q plot
    ax = axes[0, 1]
    s2 = sample.dropna()
    (osm, osr), (slope, intercept, r) = stats.probplot(s2, dist="norm")
    ax.scatter(osm, osr, s=1, c="#2e7d32", alpha=0.4)
    ax.plot([min(osm), max(osm)],
            [slope*min(osm)+intercept, slope*max(osm)+intercept], "r-", lw=1.5)
    ax.set_title(f"Normal Q-Q  (skew={skew:.2f}, kurt={kurt:.2f})")
    ax.set_xlabel("Theoretical Quantiles"); ax.set_ylabel("Sample Quantiles")

    # Rolling mean / std
    ax = axes[1, 0]
    roll_m = series.rolling(96*7).mean()    # weekly rolling
    roll_s = series.rolling(96*7).std()
    ax.plot(series.index[:min(n, 200_000)],
            series.values[:min(n, 200_000)],
            color="#aed6f1", lw=0.3, alpha=0.5, label="Power")
    ax.plot(roll_m.index[:min(n, 200_000)],
            roll_m.values[:min(n, 200_000)],
            color="navy", lw=1.2, label="Rolling Mean (1W)")
    ax.fill_between(roll_m.index[:min(n, 200_000)],
                    (roll_m - roll_s).values[:min(n, 200_000)],
                    (roll_m + roll_s).values[:min(n, 200_000)],
                    alpha=0.2, color="navy")
    ax.set_title("Rolling Mean ± 1σ (weekly window)")
    ax.set_xlabel("Time"); ax.set_ylabel("Farm Power (kW)")
    ax.legend(fontsize=8)

    # ACF
    ax = axes[1, 1]
    plot_acf(series, lags=200, ax=ax, alpha=0.05, color="#1565c0")
    ax.set_title("ACF (200 lags)")

    # PACF
    ax = axes[2, 0]
    plot_pacf(series, lags=100, ax=ax, alpha=0.05, color="#c62828", method="ywm")
    ax.set_title("PACF (100 lags)")

    # Seasonal decomposition (sample)
    ax = axes[2, 1]
    try:
        stl = STL(series[:min(n, 96*365*2)], period=96, robust=True)
        res = stl.fit()
        ax.plot(res.seasonal[:96*7], color="#2e7d32", lw=1.0)
        ax.set_title("Seasonal Component (STL, first week)")
        ax.set_xlabel("15-min intervals")
        ax.set_ylabel("Seasonal effect (kW)")
    except Exception:
        ax.text(0.5, 0.5, "STL unavailable", ha="center", va="center",
                transform=ax.transAxes)

    plt.tight_layout()
    out_path = os.path.join(out_dir, "plots", "01_statistical_analysis.png")
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info(f"Saved → {out_path}")

    return results


def print_stat_summary(results: Dict):
    sep = "─" * 60
    print(f"\n{sep}")
    print("  STATISTICAL TEST SUMMARY")
    print(sep)
    adf = results["adf"]
    print(f"  ADF Test       : p={adf['p_value']:.4f}  "
          f"{'✓ Stationary' if adf['stationary'] else '✗ Non-stationary'}")
    jb  = results["jarque_bera"]
    print(f"  Jarque-Bera    : p={jb['p_value']:.4e}  "
          f"{'✗ Non-normal' if jb['p_value'] < 0.05 else '✓ Normal-ish'}")
    print(f"  Skewness       : {results['skewness']:.3f}  "
          f"({'right' if results['skewness']>0 else 'left'}-skewed)")
    print(f"  Excess Kurtosis: {results['excess_kurtosis']:.3f}  "
          f"({'leptokurtic' if results['excess_kurtosis']>0 else 'platykurtic'})")
    print(f"  CV             : {results['cv_pct']}%")
    print(sep)
    print("  TRANSFORMATION RECOMMENDATIONS")
    print(sep)
    if results["skewness"] > 0.8:
        print("  → Log / sqrt transform may help normalize the target")
    else:
        print("  → Distribution is acceptable; RobustScaler recommended")
    if not results["adf"]["stationary"]:
        print("  → First-differencing recommended for ARIMA-class models")
    else:
        print("  → Series is stationary — AR lags safe to use directly")
    print(f"{sep}\n")

"""Physical limits and normalisation constants for the wind farm."""

MAX_DELTA_KWH = 5_000
MAX_POWER_KW = 2_600
FARM_MAX_KW = MAX_POWER_KW * 12
FARM_MAX_KWH = int(MAX_POWER_KW * 0.25 * 12)

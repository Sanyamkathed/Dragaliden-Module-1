"""Data loading and synthetic generation."""

from .loader import load_wfd_csv
from .synthetic import generate_synthetic_farm

__all__ = ["load_wfd_csv", "generate_synthetic_farm"]

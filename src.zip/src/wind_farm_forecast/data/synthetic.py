"""Synthetic wind farm data generator."""

from __future__ import annotations

import logging

import numpy as np
import pandas as pd

logger = logging.getLogger("WindFarmForecast")

def _wind_power_curve(ws: np.ndarray, rated_kw: float = 2300.0) -> np.ndarray:
    """Simplified E-82 power curve."""
    p = np.where(ws < 2.5, 0.0,
        np.where(ws < 13.0, rated_kw * ((ws - 2.5) / 10.5) ** 2.8,
        np.where(ws <= 25.0, rated_kw, 0.0)))
    return p

def generate_synthetic_farm(
    start: str = "2018-09-21",
    end: str   = "2024-12-31",
    n_turbines: int = 12,
    gap_start: str  = "2023-12-01",
    gap_end: str    = "2024-06-30",
    seed: int       = 42,
) -> pd.DataFrame:
    
    rng = np.random.default_rng(seed)
    logger.info("Generating synthetic wind farm data…")

    # Build timestamp index (15-min) and remove the gap
    all_ts = pd.date_range(start=start, end=end, freq="15min")
    gap = (all_ts >= gap_start) & (all_ts <= gap_end)
    ts_index = all_ts[~gap]
    n_ts = len(ts_index)

    rows = []
    energy_ctr = {t: rng.integers(40_000_000, 60_000_000) for t in range(1, n_turbines+1)}

    for ts in ts_index:
        # Diurnal + seasonal wind speed pattern
        hour_frac  = ts.hour + ts.minute / 60.0
        doy_frac   = ts.day_of_year / 365.0
        base_wind  = 7.5 + 2.0 * np.sin(2*np.pi*(doy_frac - 0.1))  # seasonal
        diurnal    = 1.2 * np.sin(2*np.pi*(hour_frac/24 - 0.3))
        base_wind  = max(0.0, base_wind + diurnal)

        for t in range(1, n_turbines+1):
            # Per-turbine wind (small wake / spatial variation)
            ws = max(0.0, base_wind + rng.normal(0, 0.6))
            # Randomly add faults (2% probability)
            error = int(rng.random() < 0.02) * rng.integers(1, 20)
            if error:
                ws_eff, pwr = ws, 0.0
            else:
                ws_eff = ws
                pwr = _wind_power_curve(np.array([ws]))[0] * rng.uniform(0.93, 1.0)

            nacelle = (180 + rng.normal(0, 15)) % 360
            q_kvar  = pwr * rng.uniform(-0.15, 0.10)
            prod    = pwr * 0.25                     # kWh in 15 min
            energy_ctr[t] += int(prod)
            w_hours = energy_ctr[t] // 5000         # synthetic proxy

            rows.append({
                "Date":          ts.strftime("%Y-%m-%d"),
                "Hour":          ts.hour,
                "Minute":        ts.minute,
                "Second":        0,
                "PlantNo":       t,
                "Error":         error,
                "wind_speed_ms": round(ws_eff, 1),
                "power_kw":      round(pwr, 0),
                "nacelle_pos_deg": round(nacelle, 0),
                "work_hours":    w_hours,
                "energy_ctr_kwh": energy_ctr[t],
                "reactive_kvar": round(q_kvar, 0),
                "timestamp":     ts,
            })

    df = pd.DataFrame(rows)
    logger.info(f"Synthetic data: {len(df):,} rows | {n_ts:,} timestamps | {n_turbines} turbines")
    return df

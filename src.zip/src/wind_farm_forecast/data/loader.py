"""CSV loader for real wind farm data files."""

from __future__ import annotations

import glob
import logging
import os

import pandas as pd

logger = logging.getLogger("WindFarmForecast")

CSV_COLS = [
    "Date", "Hour", "Minute", "Second", "PlantNo", "Error",
    "wind_speed_ms", "power_kw", "nacelle_pos_deg", "work_hours",
    "energy_ctr_kwh", "reactive_kvar", "timestamp",
]

NUMERIC_COLS = [
    "Hour","Minute","Second","PlantNo","Error",
    "wind_speed_ms","power_kw","nacelle_pos_deg",
    "work_hours","energy_ctr_kwh","reactive_kvar",
]


def load_wfd_csv(data_dir: str, glob_pattern: str = "**/*.csv") -> pd.DataFrame:
    """Load all WFD CSV files from a directory tree."""
    pattern = os.path.join(data_dir, glob_pattern)
    files   = sorted(glob.glob(pattern, recursive=True))
    if not files:
        raise FileNotFoundError(f"No CSV files found under: {data_dir}")

    logger.info(f"Found {len(files)} CSV files")
    dfs = []
    for fp in files:
        try:
            tmp = pd.read_csv(fp, header=None, names=CSV_COLS,
                              low_memory=False, dtype=str)
            dfs.append(tmp)
        except Exception as e:
            logger.warning(f"Skipped {fp}: {e}")

    df = pd.concat(dfs, ignore_index=True)
    logger.info(f"Raw rows loaded: {len(df):,}")

    # Parse
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    for col in NUMERIC_COLS:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=["timestamp","PlantNo"])
    df["PlantNo"] = df["PlantNo"].astype(int)
    df["Error"]   = df["Error"].fillna(0).astype(int)
    df = df.sort_values(["PlantNo","timestamp"]).reset_index(drop=True)

    logger.info(
        f"After cleaning: {len(df):,} rows | "
        f"{df['PlantNo'].nunique()} turbines | "
        f"{df['timestamp'].min().date()} → {df['timestamp'].max().date()}"
    )
    return df

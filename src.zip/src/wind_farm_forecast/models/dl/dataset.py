"""PyTorch time-series dataset."""

from __future__ import annotations

import numpy as np
import torch
from torch.utils.data import Dataset

class WindFarmDataset(Dataset):
    
    def __init__(self, X: np.ndarray, y: np.ndarray, seq_len: int):
        self.X       = torch.tensor(X, dtype=torch.float32)
        self.y       = torch.tensor(y, dtype=torch.float32)
        self.seq_len = seq_len

    def __len__(self):
        return len(self.X) - self.seq_len

    def __getitem__(self, idx):
        x_seq = self.X[idx : idx + self.seq_len]           
        y_tgt = self.y[idx + self.seq_len]                 
        return x_seq, y_tgt

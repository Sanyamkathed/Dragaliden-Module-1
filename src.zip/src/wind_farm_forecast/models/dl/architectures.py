"""PyTorch forecasting model architectures."""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn

class LSTMForecaster(nn.Module):
    
    def __init__(self, n_features: int, hidden: int, n_layers: int, dropout: float):
        super().__init__()
        self.lstm = nn.LSTM(n_features, hidden, n_layers,
                            batch_first=True, dropout=dropout if n_layers > 1 else 0.0)
        self.norm = nn.LayerNorm(hidden)
        self.head = nn.Sequential(
            nn.Linear(hidden, hidden // 2), nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden // 2, 1),
        )

    def forward(self, x):                 
        out, _ = self.lstm(x)
        out    = self.norm(out[:, -1, :])  
        return self.head(out).squeeze(-1)


class GRUForecaster(nn.Module):
    
    def __init__(self, n_features: int, hidden: int, n_layers: int, dropout: float):
        super().__init__()
        self.gru  = nn.GRU(n_features, hidden, n_layers,
                           batch_first=True, dropout=dropout if n_layers > 1 else 0.0)
        self.norm = nn.LayerNorm(hidden)
        self.head = nn.Sequential(
            nn.Linear(hidden, hidden // 2), nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden // 2, 1),
        )

    def forward(self, x):
        out, _ = self.gru(x)
        return self.head(self.norm(out[:, -1, :])).squeeze(-1)


class CNNLSTMForecaster(nn.Module):
    
    def __init__(self, n_features: int, conv_ch: int, kernel: int,
                 hidden: int, n_layers: int, dropout: float):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(n_features, conv_ch,  kernel, padding=kernel//2), nn.GELU(),
            nn.BatchNorm1d(conv_ch),
            nn.Conv1d(conv_ch, conv_ch*2, kernel, padding=kernel//2), nn.GELU(),
            nn.BatchNorm1d(conv_ch*2),
            nn.Dropout(dropout),
        )
        self.lstm = nn.LSTM(conv_ch*2, hidden, n_layers,
                            batch_first=True, dropout=dropout if n_layers > 1 else 0.0)
        self.norm = nn.LayerNorm(hidden)
        self.head = nn.Sequential(
            nn.Linear(hidden, hidden // 2), nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden // 2, 1),
        )

    def forward(self, x):                
        x = self.conv(x.permute(0, 2, 1))  
        x = x.permute(0, 2, 1)           
        out, _ = self.lstm(x)
        return self.head(self.norm(out[:, -1, :])).squeeze(-1)


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 2000, dropout: float = 0.1):
        super().__init__()
        self.drop = nn.Dropout(dropout)
        pe   = torch.zeros(max_len, d_model)
        pos  = torch.arange(max_len).unsqueeze(1).float()
        div  = torch.exp(torch.arange(0, d_model, 2).float() * (-np.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div[:d_model//2])
        self.register_buffer("pe", pe.unsqueeze(0))  

    def forward(self, x):                 
        return self.drop(x + self.pe[:, :x.size(1), :])


class TransformerForecaster(nn.Module):
    
    def __init__(self, n_features: int, d_model: int, nhead: int,
                 n_layers: int, ff_dim: int, dropout: float):
        super().__init__()
        self.proj  = nn.Linear(n_features, d_model)
        self.pos   = PositionalEncoding(d_model, dropout=dropout)
        enc_layer  = nn.TransformerEncoderLayer(
            d_model, nhead, ff_dim, dropout,
            activation="gelu", batch_first=True, norm_first=True,
        )
        self.enc   = nn.TransformerEncoder(enc_layer, n_layers,
                                            norm=nn.LayerNorm(d_model))
        self.head  = nn.Sequential(
            nn.Linear(d_model, d_model // 2), nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model // 2, 1),
        )

    def forward(self, x):                
        x = self.pos(self.proj(x))
        x = self.enc(x)
        return self.head(x[:, -1, :]).squeeze(-1)

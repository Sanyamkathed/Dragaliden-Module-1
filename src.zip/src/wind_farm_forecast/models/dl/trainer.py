"""Shared PyTorch trainer for deep-learning forecasters."""

from __future__ import annotations

import logging
import time
from copy import deepcopy
from typing import Dict, Tuple

import joblib
import numpy as np
import torch
import torch.nn as nn
from sklearn.preprocessing import MinMaxScaler
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader as TorchDataLoader

from wind_farm_forecast.config import Config, DEVICE
from wind_farm_forecast.evaluation.metrics import compute_metrics
from wind_farm_forecast.models.dl.architectures import (
    CNNLSTMForecaster,
    GRUForecaster,
    LSTMForecaster,
    TransformerForecaster,
)
from wind_farm_forecast.models.dl.dataset import WindFarmDataset

logger = logging.getLogger("WindFarmForecast")

class DLTrainer:
    
    def __init__(self, model: nn.Module, cfg: Config, model_name: str = "DL"):
        self.model      = model.to(DEVICE)
        self.cfg        = cfg
        self.name       = model_name
        self.scaler_X   = MinMaxScaler()
        self.scaler_y   = MinMaxScaler()
        self.history    = {"train_loss": [], "val_loss": []}
        self.best_state = None
        self.n_features = None

    def _make_loader(self, X: np.ndarray, y: np.ndarray,
                     shuffle: bool = False) -> TorchDataLoader:
        ds = WindFarmDataset(X, y, self.cfg.seq_len)
        return TorchDataLoader(ds, batch_size=self.cfg.batch_size,
                               shuffle=shuffle, num_workers=0, pin_memory=False)

    def fit(self, X_train: np.ndarray, y_train: np.ndarray,
            X_val: np.ndarray,   y_val: np.ndarray) -> "DLTrainer":
        self.n_features = X_train.shape[1]

        # Scale
        X_tr  = self.scaler_X.fit_transform(X_train)
        y_tr  = self.scaler_y.fit_transform(y_train.reshape(-1, 1)).ravel()
        X_vl  = self.scaler_X.transform(X_val)
        y_vl  = self.scaler_y.transform(y_val.reshape(-1, 1)).ravel()

        train_loader = self._make_loader(X_tr, y_tr, shuffle=True)
        val_loader   = self._make_loader(X_vl, y_vl, shuffle=False)

        opt       = torch.optim.AdamW(self.model.parameters(), lr=self.cfg.lr,
                                       weight_decay=1e-4)
        scheduler = ReduceLROnPlateau(opt, patience=5, factor=0.5, min_lr=1e-6)
        criterion = nn.HuberLoss(delta=0.5)   # robust to outliers

        best_val, no_improve = np.inf, 0
        t_start = time.time()

        for epoch in range(1, self.cfg.epochs + 1):
            # Train
            self.model.train()
            tr_loss = 0.0
            for xb, yb in train_loader:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                opt.zero_grad()
                pred = self.model(xb)
                loss = criterion(pred, yb)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                opt.step()
                tr_loss += loss.item() * len(xb)
            tr_loss /= max(len(train_loader.dataset), 1)

            # Validate
            self.model.eval()
            vl_loss = 0.0
            with torch.no_grad():
                for xb, yb in val_loader:
                    xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                    pred    = self.model(xb)
                    vl_loss += criterion(pred, yb).item() * len(xb)
            vl_loss /= max(len(val_loader.dataset), 1)

            self.history["train_loss"].append(tr_loss)
            self.history["val_loss"].append(vl_loss)
            scheduler.step(vl_loss)

            if vl_loss < best_val:
                best_val    = vl_loss
                no_improve  = 0
                self.best_state = deepcopy(self.model.state_dict())
            else:
                no_improve += 1

            if epoch % 10 == 0 or epoch == 1:
                elapsed = time.time() - t_start
                logger.info(f"  [{self.name}] Epoch {epoch:3d}/{self.cfg.epochs} | "
                            f"train={tr_loss:.5f}  val={vl_loss:.5f} | "
                            f"best={best_val:.5f} | {elapsed:.0f}s")

            if no_improve >= self.cfg.patience:
                logger.info(f"  [{self.name}] Early stop at epoch {epoch}")
                break

        # Restore best weights
        if self.best_state:
            self.model.load_state_dict(self.best_state)
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        X_sc  = self.scaler_X.transform(X)
        # Pad if shorter than seq_len
        if len(X_sc) <= self.cfg.seq_len:
            pad  = np.zeros((self.cfg.seq_len + 1 - len(X_sc), X_sc.shape[1]))
            X_sc = np.vstack([pad, X_sc])

        ds     = WindFarmDataset(X_sc,
                                 np.zeros(len(X_sc), dtype=np.float32),
                                 self.cfg.seq_len)
        loader = TorchDataLoader(ds, batch_size=self.cfg.batch_size,
                                 shuffle=False, num_workers=0)
        self.model.eval()
        preds = []
        with torch.no_grad():
            for xb, _ in loader:
                preds.append(self.model(xb.to(DEVICE)).cpu().numpy())
        preds = np.concatenate(preds)
        return self.scaler_y.inverse_transform(preds.reshape(-1, 1)).ravel()

    def save(self, path: str):
        payload = {
            "model_state": self.best_state or self.model.state_dict(),
            "scaler_X":    self.scaler_X,
            "scaler_y":    self.scaler_y,
            "history":     self.history,
            "n_features":  self.n_features,
            "cfg_seq_len": self.cfg.seq_len,
        }
        joblib.dump(payload, path)
        logger.info(f"  [{self.name}] Model saved → {path}")


def build_dl_models(cfg: Config, n_features: int) -> Dict[str, nn.Module]:
    return {
        "LSTM": LSTMForecaster(n_features, cfg.hidden_dim, cfg.n_lstm_layers, cfg.dropout),
        "GRU":  GRUForecaster (n_features, cfg.hidden_dim, cfg.n_lstm_layers, cfg.dropout),
        "CNN_LSTM": CNNLSTMForecaster(n_features, 32, 5,
                                      cfg.hidden_dim, cfg.n_lstm_layers, cfg.dropout),
        "Transformer": TransformerForecaster(n_features, cfg.d_model, cfg.nhead,
                                             cfg.n_tf_layers, cfg.ff_dim, cfg.tf_dropout),
    }


def train_dl_models(
    cfg: Config,
    X_train: np.ndarray, y_train: np.ndarray,
    X_val:   np.ndarray, y_val:   np.ndarray,
) -> Tuple[Dict[str, DLTrainer], Dict[str, Dict]]:
    
    n_features = X_train.shape[1]
    dl_archs   = build_dl_models(cfg, n_features)
    trainers   = {}
    metrics    = {}

    for name, arch in dl_archs.items():
        n_params = sum(p.numel() for p in arch.parameters() if p.requires_grad)
        logger.info(f"Training {name} ({n_params:,} params)…")
        trainer = DLTrainer(arch, cfg, name)
        trainer.fit(X_train, y_train, X_val, y_val)
        preds_val = trainer.predict(X_val)

        # Align lengths (seq_len offset)
        offset = cfg.seq_len
        y_al   = y_val[offset:]
        p_al   = preds_val[:len(y_al)]
        m      = compute_metrics(y_al, p_al, name)
        metrics[name] = m
        trainers[name] = trainer
        logger.info(
            f"  {name:20s} | Val MAE={m['MAE']:7.1f}  RMSE={m['RMSE']:7.1f}  "
            f"R2={m['R2']:.4f}"
        )
    return trainers, metrics

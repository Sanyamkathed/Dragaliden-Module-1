

from __future__ import annotations

import logging
from copy import deepcopy
from typing import Any, Dict, List

import joblib
import lightgbm as lgb
import numpy as np
import xgboost as xgb
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing import RobustScaler

from wind_farm_forecast.config import Config, SEED
from wind_farm_forecast.models.hmm_forecaster import HMMForecaster

logger = logging.getLogger("WindFarmForecast")

class StackingEnsemble:
    
    def __init__(self, cfg: Config, feature_cols: List[str]):
        self.cfg          = cfg
        self.feature_cols = feature_cols
        self.base_models_ : Dict[str, Any] = {}
        self.meta_model_  = Ridge(alpha=1.0)
        self._scalers     : Dict[str, RobustScaler] = {}
        self._fitted      = False

    def _get_base_estimators(self) -> Dict[str, Any]:
        return {
            "Ridge": Ridge(alpha=10.0),
            "RF":    RandomForestRegressor(n_estimators=200, max_depth=15,
                                           n_jobs=-1, random_state=SEED),
            "XGB":   xgb.XGBRegressor(n_estimators=300, learning_rate=0.05,
                                       max_depth=6, n_jobs=-1, random_state=SEED,
                                       tree_method="hist", verbosity=0),
            "LGB":   lgb.LGBMRegressor(n_estimators=300, learning_rate=0.05,
                                        num_leaves=63, n_jobs=-1, random_state=SEED,
                                        verbose=-1),
            "HMM":   HMMForecaster(n_states=self.cfg.n_hmm_states,
                                    feature_cols=self.feature_cols),
        }

    def fit(self, X_train: np.ndarray, y_train: np.ndarray) -> "StackingEnsemble":
        logger.info("Training Stacking Ensemble (OOF meta-features)…")
        tscv = TimeSeriesSplit(n_splits=self.cfg.cv_folds)

        base_est  = self._get_base_estimators()
        oof_preds = {name: np.zeros(len(y_train)) for name in base_est}

        # OOF loop
        for fold, (tr_idx, vl_idx) in enumerate(tscv.split(X_train), 1):
            Xtr, Xvl = X_train[tr_idx], X_train[vl_idx]
            ytr, _   = y_train[tr_idx], y_train[vl_idx]
            for name, est in base_est.items():
                sc   = RobustScaler()
                Xtr_ = sc.fit_transform(Xtr)
                Xvl_ = sc.transform(Xvl)
                mdl  = deepcopy(est)
                mdl.fit(Xtr_, ytr)
                oof_preds[name][vl_idx] = mdl.predict(Xvl_)

        # Build meta-feature matrix
        meta_X = np.column_stack([oof_preds[n] for n in base_est])
        self.meta_model_.fit(meta_X, y_train)

        # Refit each base model on full training data
        for name, est in base_est.items():
            sc  = RobustScaler()
            Xsc = sc.fit_transform(X_train)
            est.fit(Xsc, y_train)
            self.base_models_[name]  = est
            self._scalers[name]      = sc
            logger.info(f"  Base model '{name}' refitted on full train")

        self._base_names = list(base_est.keys())
        self._fitted = True
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        base_preds = []
        for name in self._base_names:
            Xsc  = self._scalers[name].transform(X)
            p    = self.base_models_[name].predict(Xsc)
            base_preds.append(p)
        meta_X = np.column_stack(base_preds)
        return self.meta_model_.predict(meta_X)

    def save(self, path: str):
        joblib.dump(self, path)
        logger.info(f"  StackingEnsemble saved → {path}")

"""Statsmodels autoregressive forecaster."""

from __future__ import annotations

import logging

import joblib
import numpy as np
import pandas as pd
from statsmodels.tsa.ar_model import AutoReg

logger = logging.getLogger("WindFarmForecast")

class AutoRegForecaster:
    
    def __init__(self, lags: int = 96, seasonal: bool = True, period: int = 96):
        self.lags     = lags
        self.seasonal = seasonal
        self.period   = period
        self._fit     = None
        self._model   = None
        self._train_end_idx = 0

    def fit(self, y_train: np.ndarray) -> "AutoRegForecaster":
        logger.info(f"Training AutoReg (lags={self.lags}, seasonal={self.seasonal})…")
        series = pd.Series(y_train, dtype=float)
        self._model = AutoReg(series, lags=self.lags,
                              seasonal=self.seasonal, period=self.period,
                              old_names=False)
        self._fit  = self._model.fit(cov_type="HC0")
        self._train_end_idx = len(y_train)
        return self

    def predict_rolling(self, y_context: np.ndarray, n_steps: int) -> np.ndarray:
        
        # Use fitted model's predict for validation / test window
        start = self._train_end_idx
        end   = start + n_steps - 1
        pred  = self._fit.predict(start=start, end=end, dynamic=True)
        return np.asarray(pred)

    def save(self, path: str):
        joblib.dump(self, path)
        logger.info(f"  AutoReg saved → {path}")

"""Classical machine-learning model factories and training helpers."""

from __future__ import annotations

import logging
import time
from copy import deepcopy
from typing import Dict, List

import lightgbm as lgb
import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import TimeSeriesSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import RobustScaler
from sklearn.svm import SVR

from wind_farm_forecast.config import Config, SEED
from wind_farm_forecast.evaluation.metrics import compute_metrics

logger = logging.getLogger("WindFarmForecast")

def build_ml_models(cfg: Config) -> Dict[str, Pipeline]:
    
    scaler = RobustScaler()

    models = {
        "LinearRegression": Pipeline([
            ("scaler", RobustScaler()),
            ("model",  LinearRegression()),
        ]),
        "Ridge": Pipeline([
            ("scaler", RobustScaler()),
            ("model",  Ridge(alpha=10.0, random_state=SEED)),
        ]),
        "RandomForest": Pipeline([
            ("scaler", RobustScaler()),
            ("model",  RandomForestRegressor(
                n_estimators=300, max_depth=20, min_samples_leaf=5,
                max_features=0.5, n_jobs=-1, random_state=SEED,
            )),
        ]),
        "XGBoost": Pipeline([
            ("scaler", RobustScaler()),
            ("model",  xgb.XGBRegressor(
                n_estimators=500, learning_rate=0.05, max_depth=7,
                subsample=0.8, colsample_bytree=0.8, reg_alpha=0.1,
                reg_lambda=1.0, n_jobs=-1, random_state=SEED,
                tree_method="hist", verbosity=0,
            )),
        ]),
        "LightGBM": Pipeline([
            ("scaler", RobustScaler()),
            ("model",  lgb.LGBMRegressor(
                n_estimators=500, learning_rate=0.05, max_depth=7,
                num_leaves=127, subsample=0.8, colsample_bytree=0.8,
                reg_alpha=0.1, n_jobs=-1, random_state=SEED, verbose=-1,
            )),
        ]),
        #"SVR": Pipeline([
           # ("scaler", StandardScaler()),
            #("model",  SVR(kernel="rbf", C=100, epsilon=50, gamma="scale")),
        #]),
    }
    return models


def train_ml_models(
    models: Dict[str, Pipeline],
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val:   np.ndarray,
    y_val:   np.ndarray,
    cfg:     Config,
) -> Dict[str, Dict]:
    
    results = {}
    for name, pipe in models.items():
        t0 = time.time()
        logger.info(f"Training {name}…")

        # Use time-series CV on train to guide fit quality
        tscv = TimeSeriesSplit(n_splits=cfg.cv_folds)
        cv_scores = []
        for fold_tr, fold_val in tscv.split(X_train):
            pipe_cv = deepcopy(pipe)
            pipe_cv.fit(X_train[fold_tr], y_train[fold_tr])
            pred_cv = pipe_cv.predict(X_train[fold_val])
            cv_scores.append(np.sqrt(mean_squared_error(y_train[fold_val], pred_cv)))

        # Final fit on full training set
        pipe.fit(X_train, y_train)
        pred_val = pipe.predict(X_val)
        m = compute_metrics(y_val, pred_val, name)
        m["cv_rmse_mean"] = round(np.mean(cv_scores), 2)
        m["cv_rmse_std"]  = round(np.std(cv_scores), 2)
        m["train_time_s"] = round(time.time() - t0, 1)
        results[name] = m
        logger.info(
            f"  {name:20s} | Val MAE={m['MAE']:7.1f}  RMSE={m['RMSE']:7.1f}  "
            f"R2={m['R2']:.4f} | {m['train_time_s']:.1f}s"
        )
    return results


def get_feature_importance(pipe: Pipeline, feature_cols: List[str]) -> pd.DataFrame:
    
    model = pipe.named_steps["model"]
    if hasattr(model, "feature_importances_"):
        imp = model.feature_importances_
    else:
        return pd.DataFrame()
    fi = pd.DataFrame({"feature": feature_cols, "importance": imp})
    return fi.sort_values("importance", ascending=False).head(30)

"""HMM regime-aware LightGBM forecaster."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import joblib
import lightgbm as lgb
import numpy as np
try:
    from hmmlearn import hmm as hmmlearn_hmm
except ImportError:  
    hmmlearn_hmm = None
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.preprocessing import StandardScaler

from wind_farm_forecast.config import SEED

logger = logging.getLogger("WindFarmForecast")

class HMMForecaster(BaseEstimator, RegressorMixin):
    
    def __init__(self, n_states: int = 4, feature_cols: Optional[List] = None):
        self.n_states     = n_states
        self.feature_cols = feature_cols
        self.hmm_         = None
        self.regime_models_: Dict[int, Any] = {}
        self.fallback_    = None
        self._scaler_hmm  = StandardScaler()
        self._fitted      = False

    # ── Observation features for HMM (low-dimensional)
    def _hmm_obs(self, X: np.ndarray, feature_cols: List[str]) -> np.ndarray:
        
        names = feature_cols
        idx   = {}
        for key in ["avg_wind_speed_ms", "farm_production_kwh_lag_1", "hour_sin", "hour_cos"]:
            matching = [i for i, c in enumerate(names) if key in c]
            idx[key] = matching[0] if matching else None

        # Build observation array
        cols = []
        for key, i in idx.items():
            if i is not None:
                cols.append(X[:, i])
        if not cols:
            # Fallback: first 4 cols
            cols = [X[:, i] for i in range(min(4, X.shape[1]))]
        return np.column_stack(cols)

    def fit(self, X: np.ndarray, y: np.ndarray) -> "HMMForecaster":
        if hmmlearn_hmm is None:
            raise ImportError(
                "HMMForecaster requires the optional dependency 'hmmlearn'. "
                "Install it with `pip install hmmlearn` or skip HMM usage."
            )
        logger.info(f"Training HMMForecaster (n_states={self.n_states})…")
        obs = self._scaler_hmm.fit_transform(self._hmm_obs(X, self.feature_cols or []))

        self.hmm_ = hmmlearn_hmm.GaussianHMM(
            n_components=self.n_states, covariance_type="full",
            n_iter=200, random_state=SEED, tol=1e-4,
        )
        self.hmm_.fit(obs)
        regimes = self.hmm_.predict(obs)

        for state in range(self.n_states):
            mask = regimes == state
            cnt  = mask.sum()
            if cnt >= 200:
                m = lgb.LGBMRegressor(n_estimators=300, learning_rate=0.05,
                                       num_leaves=63, verbose=-1, random_state=SEED)
                m.fit(X[mask], y[mask])
                self.regime_models_[state] = m
                logger.info(f"  Regime {state}: {cnt:,} samples → LGB trained")
            else:
                self.regime_models_[state] = None
                logger.info(f"  Regime {state}: {cnt:,} samples → too few, fallback")

        # Global fallback
        self.fallback_ = lgb.LGBMRegressor(n_estimators=300, learning_rate=0.05,
                                             num_leaves=63, verbose=-1, random_state=SEED)
        self.fallback_.fit(X, y)
        self._fitted = True
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        obs     = self._scaler_hmm.transform(self._hmm_obs(X, self.feature_cols or []))
        regimes = self.hmm_.predict(obs)
        preds   = np.zeros(len(X))

        for state in range(self.n_states):
            mask  = regimes == state
            if not mask.any():
                continue
            model = self.regime_models_.get(state) or self.fallback_
            preds[mask] = model.predict(X[mask])
        return preds

    def save(self, path: str):
        joblib.dump(self, path)
        logger.info(f"  HMMForecaster saved → {path}")
